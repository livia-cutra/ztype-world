import tester.*;             
import javalib.worldimages.*;  
import javalib.funworld.*;      
import java.awt.Color;   
import java.util.Random;

//represents a list of words
interface ILoWord {
  
  // takes in a letter and if the letter matches the first 
  //letter of a word in the list, erase that letter off the word
  ILoWord checkAndReduce(String s);
  
  //adds a given word to the end of the list
  ILoWord addToEnd(IWord word);
  
  //checks if a list is empty or a cons
  boolean isEmpty();
  
  // draws our WorldScene
  WorldScene draw(WorldScene scene); 
  
  //checks if a word has a first letter that matches the given string and if it does, 
  //it will change that word to an active word and erase that letter from the word
  ILoWord applyKey(String s);
  
  //returns a new list with all of its element's y-coordinates increased by 1
  ILoWord moveDown();
  
  //goes through the list and checks if any of the y-coordinates of the words have surpassed
  //a certain point, and if any of them have, returns true to initiate the end of the game
  boolean endsGame();
  
  //adds up how many activeWords are in the list
  int activeLength();
  
  //removes any words in a list that are empty strings
  ILoWord filterOutEmpties();
}

//represents an empty list of words
class MtLoWord implements ILoWord {
  
  /* TEMPLATE:
   * Fields:
   * Methods:
   * ...this.checkAndReduce(String s)...      --ILoWord
   * ...this.addToEnd(IWord word)...          --ILoWord
   * ...isEmpty()...                          --boolean
   * ...this.draw(WorldScene scene)...        --WorldScene
   * ...this.applyKey(String s)...            --ILoWord
   * ...this.moveDown()...                    --ILoWord
   * ...this.endsGame()...                    --boolean
   * ...this.activeLength()...                --int
   * ...this.filterOutEmpties()...            --ILoWord
   */
  
  //applying checkAndReduce to an empty list of words
  public ILoWord checkAndReduce(String s) {
    return this;
  }
  
  //applying addToEnd to an empty list of words, making the given word now the only word in the list
  public ILoWord addToEnd(IWord word) {
    return new ConsLoWord(word, this);
  }
  
  //checks if the empty list has no values in it
  public boolean isEmpty() {
    return true;
  }
 
  //applying WorldScene to an empty list of words
  public WorldScene draw(WorldScene scene) {
    return scene;
  }
  
  //goes through an empty list looking for a word to match, 
  //but finds that there are none so returns itself unchanged
  public ILoWord applyKey(String s) {
    return this;
  }
  
  //adds one to the y-coordinate of every value, but this list has no values so will return this unchanged
  public ILoWord moveDown() {
    return this;
  }
  
  //checks if any words in the list have a surpassing y-coordinate, empty has none so will return false
  public boolean endsGame() {
    return false;
  }
  
  //applies activeLength() to an empty list, which should always return 0
  public int activeLength() {
    return 0;
  }
  
  //applied to an empty list, which will return itself cause there are no strings to check regardless 
  public ILoWord filterOutEmpties() {
    return this;
  }
}

//represents a list of words
class ConsLoWord implements ILoWord {
  IWord first;
  ILoWord rest;

  //constructor
  ConsLoWord(IWord first, ILoWord rest) {
    this.first = first;
    this.rest = rest;
  }
  
  /* TEMPLATE:
   * Fields:
   * ...this.first...   --String
   * ...this.rest...    --String
   * Methods:
   * ...this.checkAndReduce(String s)...      --ILoWord
   * ...this.addToEnd(IWord word)...          --ILoWord
   * ...isEmpty()...                          --boolean
   * ...this.draw(WorldScene scene)...        --WorldScene
   * ...this.applyKey(String s)...            --ILoWord
   * ...this.moveDown()...                    --ILoWord
   * ...this.endsGame()...                    --boolean
   * ...this.activeLength()...                --int
   * ...this.filterOutEmpties()...            --ILoWord
   */

  //applying checkAndReduce to a list of words, if the letter matches the first 
  //letter of a word in the list, erase that letter off the word
  public ILoWord checkAndReduce(String s) {
    if (this.first.isMatch(s)) {
      return new ConsLoWord(this.first.reduce(), this.rest.checkAndReduce(s));
    } else {
      return new ConsLoWord(this.first, this.rest.checkAndReduce(s));
    }
  }
  
  //applying addToEnd to a list of words, adding the given word to the end of the list
  public ILoWord addToEnd(IWord word) {
    if (this.rest.isEmpty()) {
      return new ConsLoWord(this.first, new MtLoWord().addToEnd(word));
    } else {
      return new ConsLoWord(this.first,  this.rest.addToEnd(word));
    }
  }
  
  //checks if a list of words is empty
  public boolean isEmpty() {
    return false;
  }

  //applying WorldScene to a list of words, drawing them on the scene
  public WorldScene draw(WorldScene scene) {
    return this.rest.draw(this.first.drawHelp(scene));
  }
  
  //checks if a word has a first letter that matches the given string and if it does, 
  //it will change that word to an active word and erase that letter from the word
  public ILoWord applyKey(String s) {
    //check if any words are active first??    
    if (this.first.isMatch(s)) {
      return new ConsLoWord (this.first.makeActive(), this.rest);
    } else {
      return new ConsLoWord (this.first, this.rest.applyKey(s));
    }
  }
  
  //adding 1 to the y-coordinate of every word in the list
  public ILoWord moveDown() {
    return new ConsLoWord(this.first.addY(), this.rest.moveDown());
  }

  //checking if any of the words in this list of words surpasses a certain y-coordinate, 
  // to initiate the end of the game
  public boolean endsGame() {
    return this.first.reachesBottom() || this.rest.endsGame();
  }  
  
  //adds up the amount of activeWords in a list of words
  public int activeLength() {
    return this.first.checkLength() + this.rest.activeLength();
  }
  
  //removes any words that are named as an empty string from the list of words
  public ILoWord filterOutEmpties() {
    if (this.first.stringIsEmpty()) {
      return this.rest.filterOutEmpties();
    } else {
      return new ConsLoWord(this.first, this.rest.filterOutEmpties());
    }
  }
}


//represents a word in the ZType game
interface IWord {
  //represents/draws the word at hand
  WorldImage textToImage();
  
  //checks if the string in a word is empty ("")
  boolean stringIsEmpty();
  
  //places a drawn word onto the scene using x and y coordinates
  WorldScene drawHelp(WorldScene scene);
  
  //checks if the first letter of a word matches the string given
  boolean isMatch(String s);
  
  //erases the first letter of a word
  IWord reduce();
  
  //makes a word active
  IWord makeActive();
  
  //adds 1 to the y-coordinate
  IWord addY();
  
  //checks if the y-coordinate surpasses a certain number that represents the bottom of the scene
  boolean reachesBottom();
  
  //represents an active/inactive word with a number, 1 if it is active, 0 if it is inactive
  int checkLength();
  
}

//represents an active word in the ZType game
class ActiveWord implements IWord {
  String word;
  int x;
  int y;

  ActiveWord(String word, int x, int y) {
    this.word = word;
    this.x = x;
    this.y = y;
  }

  /* TEMPLATE:
   * Fields:
   * ...this.word...   --String
   * ...this.x...      --int
   * ...this.y...      --int
   * Methods:
   * ...this.textToImage...                 --WorldImage
   * ...this.stringIsEmpty()...             --boolean
   * ...this.drawHelp(WorldScene scene)...  --WorldScene
   * ...this.isMatch(String s)...           --boolean
   * ...this.reduce()...                    --IWord
   * ...this.makeACtive()...                --IWord
   * ...this.addY()...                      --IWord
   * ...this.reachesBottom()...             --boolean
   * ...this.checkLength()...               --int
   * */
  
  //checks if the first letter of an active word matches the string given
  public boolean isMatch(String s) {
    return word.startsWith(s);
  }
   
  //erases the first letter of an active word
  public IWord reduce() {
    return new ActiveWord(word.substring(1), x, y);
  }
  
  //checks if the string in an active word is empty ("")
  public boolean stringIsEmpty() {
    return word.isEmpty();
  }
  
  //represents/draws the active word
  public WorldImage textToImage() {
    return new TextImage(this.word, 20, FontStyle.REGULAR, Color.BLACK);
  }

  //places a drawn active word onto the scene using x and y coordinates
  public WorldScene drawHelp(WorldScene scene) {
    return scene.placeImageXY(this.textToImage(), this.x, this.y);
  }
  
  //returns this word because it is already active
  public IWord makeActive() {
    return this;
  }
  
  //increases y coordinate by 1 every tick so it moves down gradually
  public IWord addY() {
    return new ActiveWord(this.word, this.x, this.y + 1);//increases y coordinate by 1 every tick so it moves down gradually
  }
  
  //checks if the y-coordinate surpasses a certain number that represents the bottom of the scene
  public boolean reachesBottom() {
    return this.y >= 600;
  }
  
  //represents an active word with a number, 1 , to count it as an active word
  public int checkLength() {
    return 1;
  }
}


//represents an inactive word in the ZType game
class InactiveWord implements IWord {
  String word;
  int x;
  int y;


  InactiveWord(String word, int x, int y) {
    this.word = word;
    this.x = x;
    this.y = y;
  }
  
  /* TEMPLATE:
   * Fields:
   * ...this.word...   --String
   * ...this.x...      --int
   * ...this.y...      --int
   * Methods:
   * ...this.textToImage...                 --WorldImage
   * ...this.stringIsEmpty()...             --boolean
   * ...this.drawHelp(WorldScene scene)...  --WorldScene
   * ...this.isMatch(String s)...           --boolean
   * ...this.reduce()...                    --IWord
   * ...this.makeACtive()...                --IWord
   * ...this.addY()...                      --IWord
   * ...this.reachesBottom()...             --boolean
   * ...this.checkLength()...               --int
   * */
  
  //checks if the first letter of an inactive word matches the string given
  public boolean isMatch(String s) {
    return word.startsWith(s);
  }
  
  //erases the first letter of an inactive word
  public IWord reduce() {
    return this;
  }
  
  //checks if the string in an inactive word is empty ("")
  public boolean stringIsEmpty() {
    return word.isEmpty();
  }
  
  //represents/draws the active word
  public WorldImage textToImage() {
    return new TextImage(this.word, 20, FontStyle.REGULAR, Color.RED);
  }

  //places a drawn inactive word onto the scene using x and y coordinates
  public WorldScene drawHelp(WorldScene scene) {
    return scene.placeImageXY(this.textToImage(), this.x, this.y);
  }
  
  //makes this inactive word active
  public IWord makeActive() {
    return new ActiveWord(this.word, this.x, this.y);
  }
  
  //increases y coordinate by 1 every tick so it moves down gradually
  public IWord addY() {
    return new InactiveWord(this.word, this.x, this.y + 1);
  }
  
  //checks if the y-coordinate surpasses a certain number that represents the bottom of the scene
  public boolean reachesBottom() {
    return this.y >= 600;
  }
  
  //represents an inactive word with a number, 0 , to not count it as an active word  
  public int checkLength() {
    return 0;
  }
}
  
interface IConstant {
  int B_HEIGHT = 600;
  int B_WIDTH = 500;
  String ALPHABET = "abcdefghijklmnopqrstuvwxyz";
}

class Utils implements IConstant {
  
  /* TEMPLATE:
   * Fields:
   * Methods:
   * ...this.randomLetter(int length, Random rand)...     --String
   * */
  
  //if the length is 0, return empty string, otherwise return call 
  // same method w minus one for length + random letter
  
  // produces a string of random 6 letters
  public String randomLetters(int length, Random rand) {
    if (length <= 0) {
      return "";
    } else {
      char randomChar = ALPHABET.charAt(rand.nextInt(ALPHABET.length())); //gives random character 
      return randomLetters(length - 1, rand) + randomChar;
    }
  }
}

class ZTypeWorld extends World implements IConstant {
  
  Random rand; 
  ILoWord words;
  int tickCount;
  
  ZTypeWorld(ILoWord words) {
    this(words, new Random(), 0);
    this.words = words; 
  }
    
  ZTypeWorld(ILoWord words, Random rand, int tickCount) {
    this.words = words;
    this.rand = rand;
    this.tickCount = tickCount;
  }
  
  /* TEMPLATE :
   * Fields :
   * ...this.rand...        --Random
   * ...this.words...       --ILoWord
   * ...this.tickCount...   --int
   * Methods : 
   * ...makeScene()...             --WorldScene
   * ...onTick()...                --World
   * ...worldEnds()...             --WorldEnd
   * ...makeAFinalScene()...       --WorldScene
   * ...moveWordsDown()...         --ILoWord
   * ...onKeyEvent(String s)...    --ZTypeWorld
   */
  
  //draws the current state of the world
  public WorldScene makeScene() {
    return this.words.draw(new WorldScene(B_WIDTH, B_HEIGHT));   
  }

  //increases the y coordinates of every word in the list
  public ILoWord moveWordsDown() {
    return this.words.moveDown();
  }
  
  @Override 
  //updates the world on every tick
  public World onTick() {
     // increment tick count
     tickCount = tickCount + 1;

      ILoWord updatedWords = this.moveWordsDown();
      ILoWord updatedWordsList = updatedWords;
      
      // adds a new random word every few ticks
      if (tickCount % 8 == 0) { 
          String randomWord = new Utils().randomLetters(6, this.rand);
          int randomX = 20 + this.rand.nextInt(B_WIDTH - 40);
          int randomY = 0; // Starts at the top
          IWord newWord = new InactiveWord(randomWord, randomX, randomY);          
          updatedWordsList = this.words.addToEnd(newWord);
      }     
      //returns updated world
      return new ZTypeWorld(updatedWordsList, this.rand, this.tickCount);     
  }
   
   @Override 
   //decides when the game is over
   public WorldEnd worldEnds() {
     if (this.words.endsGame()) {
       return new WorldEnd(true, this.makeAFinalScene());
     } else {
       return new WorldEnd(false, this.makeScene());
     }
   }
   
   //shows/displays the player the game is over on the screen
   public WorldScene makeAFinalScene() {
     WorldScene endScene = new WorldScene(B_WIDTH, B_HEIGHT);
     return endScene.placeImageXY(new TextImage ("GAME OVER", 80, FontStyle.BOLD, Color.BLACK), 250, 300); 
   }
 
   @Override 
  //handles user key input
  public ZTypeWorld onKeyEvent(String s) {    
    if (this.words.activeLength() == 0) {     
      return new ZTypeWorld(this.words.applyKey(s).checkAndReduce(s).filterOutEmpties()); 
    } else {
      return new ZTypeWorld(this.words.checkAndReduce(s).filterOutEmpties());
    }
  }  
}

//examples and tests for the game
class ZTypeWorldExamples {
  ZTypeWorldExamples() {}
  
  //examples of active and inactive words
  IWord activeApple = new ActiveWord("Apple", 100, 10);  
  IWord activeLemon = new ActiveWord("Lemon", 70, 12);
  IWord inactiveLime = new InactiveWord("Lime", 180, 10);
  IWord activeElephantine = new ActiveWord("Elephantine", 200, 15);
  IWord activeGrapeFruit = new ActiveWord("GrapeFruit", 300, 17);
  IWord activeEmpty = new ActiveWord("", 120, 20);
  IWord inactiveBanana = new InactiveWord("Banana", 260, 11);
  IWord inactiveElephant = new InactiveWord("Elephant", 350, 14);
  IWord inactiveGrape = new InactiveWord("Grape", 110, 16);
  IWord inactiveCat = new InactiveWord("Cat", 130, 18);
  IWord inactiveDog = new InactiveWord("Dog", 140, 19);
  IWord inactivePeach = new InactiveWord("Peach", 250, 20);
  IWord inactivePear = new InactiveWord("Pear", 160, 21);
  
    
  //examples of lists with active and inactive words
  ILoWord nowords = new MtLoWord();
  ILoWord lista = new ConsLoWord(activeApple, new ConsLoWord(inactiveBanana,nowords));
  ILoWord listb =  new ConsLoWord(activeLemon, new ConsLoWord(inactiveLime, 
                   new ConsLoWord(inactiveElephant,nowords)));
  ILoWord listc = new ConsLoWord(inactiveGrape, new ConsLoWord(inactivePeach, 
                                                new ConsLoWord(activeGrapeFruit,
                                                new ConsLoWord(inactivePear,nowords))));
  ILoWord listd = new ConsLoWord(activeLemon, new ConsLoWord(inactivePear, 
                                              new ConsLoWord(activeEmpty, nowords)));
 
  //examples of WorldScenes
  WorldScene emptyScene = new WorldScene(500, 600);
  WorldScene sceneLista = lista.draw(new WorldScene(500, 600));
  WorldScene sceneListb = listb.draw(new WorldScene(500, 600));
  WorldScene sceneListc = listc.draw(new WorldScene(500, 600));
  WorldScene sceneListd = listd.draw(new WorldScene(500, 600));
  
  //examples of World
  World emptyWorld = new ZTypeWorld(nowords);
  World firstWorld = new ZTypeWorld(lista);
  World secondWorld = new ZTypeWorld(listb);
  World thirdWorld = new ZTypeWorld(listc);
  World fourthWorld = new ZTypeWorld(listd);
  
  //examples of random options
  World rand1 = new ZTypeWorld(nowords, new Random(3), 0);
  World rand2 = new ZTypeWorld(lista, new Random(7), 0);
  World rand3 = new ZTypeWorld(listb, new Random(15), 0);
  World rand4 = new ZTypeWorld(listc, new Random(20), 0);
  
  //examples of testing BigBang
  boolean testBigBang(Tester t) {
    ZTypeWorld world  = new ZTypeWorld(this.listb);
    int worldWidth = 500;
    int worldHeight = 600;
    double TickRate = 0.1;
    return world.bigBang(worldWidth, worldHeight, TickRate);
  }
  
  //testing makeScene  method
  boolean testmakeScene(Tester t) {
    return
     t.checkExpect(emptyWorld.makeScene(), emptyScene)
      &&
     t.checkExpect(firstWorld.makeScene(), 
                   lista.draw(new WorldScene(500, 600)))
      &&
     t.checkExpect(secondWorld.makeScene(), 
                   listb.draw(new WorldScene(500, 600)))
      &&
     t.checkExpect(thirdWorld.makeScene(), 
                   listc.draw(new WorldScene(500, 600)))
      &&
     t.checkExpect(fourthWorld.makeScene(), 
                   listd.draw(new WorldScene(500, 600)));

  }
    
  //testing randomLetters method 
  boolean testrandomLetters(Tester t) {
    return 
        t.checkExpect(new Utils().randomLetters(6, new Random(10)), "seylgp")
        &&
        t.checkExpect(new Utils().randomLetters(6, new Random(20)), "phpvsx")
        &&
        t.checkExpect(new Utils().randomLetters(6, new Random(7)), "aikdmq");
  }
  
  boolean testCheckAndReduce(Tester t) {
    return
        t.checkExpect(nowords.checkAndReduce("A"), nowords)
        &&
        t.checkExpect(new ConsLoWord(new InactiveWord("Banana", 6, 11),
                                         nowords).checkAndReduce("B"), 
                                         new ConsLoWord(new InactiveWord("Banana", 6, 11), nowords))
        &&
        t.checkExpect(new ConsLoWord(new ActiveWord("Apple", 5, 10), nowords).checkAndReduce("A"),
                new ConsLoWord(new ActiveWord("pple", 5, 10), nowords));
  }
  
  // Testing addToEnd method
  boolean testAddToEnd(Tester t) {
    return
      t.checkExpect(nowords.addToEnd(activeApple), (new ConsLoWord(activeApple, nowords)))
      &&
      t.checkExpect(lista.addToEnd(activeApple), new ConsLoWord(activeApple, 
                                                     new ConsLoWord(inactiveBanana, 
                                                         new ConsLoWord(activeApple, nowords))))
      &&
      t.checkExpect(listb.addToEnd(inactiveElephant), new ConsLoWord(activeLemon, 
                                                          new ConsLoWord(inactiveLime, 
                                                              new ConsLoWord(inactiveElephant,
                                                      new ConsLoWord(inactiveElephant, nowords)))))
      &&
      t.checkExpect(listc.addToEnd(activeEmpty), 
              new ConsLoWord(inactiveGrape, 
                      new ConsLoWord(inactivePeach, 
                              new ConsLoWord(activeGrapeFruit, 
                                      new ConsLoWord(inactivePear, 
                                          new ConsLoWord(activeEmpty, nowords))))));
  }
  
  //Testing filterOutEmpties method
  boolean testFilterOutEmpties(Tester t) {
    return
      t.checkExpect(nowords.filterOutEmpties(), nowords)
      &&
      t.checkExpect(lista.filterOutEmpties(), lista)
      &&
      t.checkExpect(listb.filterOutEmpties(), listb)
      &&
      t.checkExpect(listd.filterOutEmpties(), 
              new ConsLoWord(activeLemon, 
                  new ConsLoWord(inactivePear, nowords)));
  }
  
  //Testing draw method
  boolean testDraw(Tester t) {
    return
     t.checkExpect(nowords.draw(new WorldScene(500, 600)), emptyScene)
      &&
     t.checkExpect(lista.draw(new WorldScene(500, 600)), 
                   emptyScene.placeImageXY(new TextImage("Apple", 20, Color.BLACK), 100, 10)
                             .placeImageXY(new TextImage("Banana", 20, Color.RED), 260, 11));

  }
  
  //Test cases for isEmpty method
  boolean testIsEmpty(Tester t) {
    return
      t.checkExpect(nowords.isEmpty(), true)
        &&
      t.checkExpect(listc.isEmpty(), false);
  }

  // Test cases for applyKey method
  boolean testApplyKey(Tester t) {
    return      
      t.checkExpect(nowords.applyKey("A"), nowords)
        &&
      t.checkExpect(listc.applyKey("G"),
              new ConsLoWord(
                      new ActiveWord("Grape", 110, 16),
                      new ConsLoWord(
                              new InactiveWord("Peach", 250, 20),
                                  new ConsLoWord(
                                      new ActiveWord("GrapeFruit", 300, 17),
                                      new ConsLoWord(
                                          new InactiveWord("Pear", 160, 21),
                              new MtLoWord())))))
       &&      
    t.checkExpect(listc.applyKey("L"),
        new ConsLoWord(
                new InactiveWord("Grape", 110, 16),
                new ConsLoWord(
                        new InactiveWord("Peach", 250, 20),
                            new ConsLoWord(
                                new ActiveWord("GrapeFruit", 300, 17),
                                new ConsLoWord(
                                    new InactiveWord("Pear", 160, 21),
                        new MtLoWord())))));
  }

  // Test cases for moveDown method
  boolean testMoveDown(Tester t) {
    return 
      t.checkExpect(nowords.moveDown(), nowords)
        &&
      t.checkExpect(lista.moveDown(),
              new ConsLoWord(
                      new ActiveWord("Apple", 100, 11),
                      new ConsLoWord(
                              new InactiveWord("Banana", 260, 12),
                              new MtLoWord())));
  }

  // Test cases for endsGame method
  boolean testEndsGame(Tester t) {
      ILoWord listWithWords = new ConsLoWord(
              new ActiveWord("Apple", 100, 100),
              new ConsLoWord(
                      new InactiveWord("Banana", 150, 600),
                      new MtLoWord()));
      return
      t.checkExpect(nowords.endsGame(), false)
         &&
      t.checkExpect(listWithWords.endsGame(), true);
  }

  // Test cases for activeLength method
  boolean testActiveLength(Tester t) {
    return
      t.checkExpect(nowords.activeLength(), 0)
        &&
      t.checkExpect(listc.activeLength(), 1);
  }
  
  //tests for helpers :::
  
  //Test cases for textToImage method
  boolean testTextToImage(Tester t) {
      return
      t.checkExpect(activeApple.textToImage(),
              new TextImage("Apple", 20, FontStyle.REGULAR, Color.BLACK))
        &&
      t.checkExpect(inactiveBanana.textToImage(),
              new TextImage("Banana", 20, FontStyle.REGULAR, Color.RED));
  }

  // Test cases for stringIsEmpty method
  boolean testStringIsEmpty(Tester t) {
    return
      t.checkExpect(new ActiveWord("", 100, 100).stringIsEmpty(), true)
        &&
      t.checkExpect(inactivePear.stringIsEmpty(), false);
  }

  // Test cases for drawHelp method
  boolean testDrawHelp(Tester t) {
      WorldScene scene = new WorldScene(500, 600);
   return
      t.checkExpect(activeApple.drawHelp(scene),
              scene.placeImageXY(new TextImage("Apple", 20, FontStyle.REGULAR, Color.BLACK), 100, 10))
        &&
      // Edge case: Test when the word is inactive
      t.checkExpect(inactiveBanana.drawHelp(scene),
              scene.placeImageXY(new TextImage("Banana", 20, FontStyle.REGULAR, Color.RED), 260, 11));
  }

  // Test cases for isMatch method
  boolean testIsMatch(Tester t) {
    return
      t.checkExpect(activeApple.isMatch("A"), true)
        &&
      t.checkExpect(activeApple.isMatch("a"), false)
        &&
      t.checkExpect(activeApple.isMatch("b"), false);
  }

  // Test cases for reduce method
  boolean testReduce(Tester t) {
    return
      t.checkExpect(activeApple.reduce(), new ActiveWord("pple", 100, 10));
  }

  // Test cases for makeActive method
  boolean testMakeActive(Tester t) {
      return 
      t.checkExpect(inactiveBanana.makeActive(), new ActiveWord("Banana", 260, 11));
  }

  // Test cases for addY method
  boolean testAddY(Tester t) {
    return
      t.checkExpect(activeApple.addY(), new ActiveWord("Apple", 100, 11));
  }

  // Test cases for reachesBottom method
  boolean testReachesBottom(Tester t) {
    return
      t.checkExpect(activeApple.reachesBottom(), false)
        &&
      t.checkExpect(new ActiveWord("hi", 50, 700).reachesBottom(), true);
  }

  // Test cases for checkLength method
  boolean testCheckLength(Tester t) {
    return
      t.checkExpect(activeApple.checkLength(), 1)
         &&
      t.checkExpect(inactiveBanana.checkLength(), 0);
  }

}


